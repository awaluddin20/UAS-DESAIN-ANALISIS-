from flask import Flask, render_template, jsonify, request
from solver import solve_with_stats
import os, json, time, random

app = Flask(__name__)
STATE_FILE = "state.json"

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def generate_random_obstacles(rows, cols, protected, target=40):
    rnd = random.Random(time.time_ns())
    obs = set()
    while len(obs) < target:
        r, c = rnd.randrange(rows), rnd.randrange(cols)
        if (r, c) not in protected:
            obs.add((r, c))
    return obs

def load_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, "r") as f:
                data = json.load(f)
                return {
                    "rows": data.get("rows", 15),
                    "cols": data.get("cols", 15),
                    "start": tuple(data.get("start", [2, 3])),
                    "goal": tuple(data.get("goal", [10, 10])),
                    "obstacles": set(tuple(x) for x in data.get("obstacles", []))
                }
        except: pass
    return {"rows": 15, "cols": 15, "start": (2, 3), "goal": (10, 10), "obstacles": set()}

STATE = load_state()

def build_response(rows, cols, start, goal, obstacles):
    # Memanggil solver yang sudah mendukung multi-path
    stats = solve_with_stats(rows, cols, start, goal, obstacles)
    all_paths = stats.get("all_paths", [])
    
    return {
        "status": stats.get("status", "Standby"),
        "rows": rows,
        "cols": cols,
        "start": list(start),
        "goal": list(goal),
        "obstacles": [list(x) for x in sorted(obstacles)],
        "time_ms": float(stats.get("time_ms", 0)),
        "nodes": int(stats.get("nodes", 0)),
        # Mengirim 3 jalur agar terbaca di dropdown
        "paths": [[list(p) for p in path] for path in all_paths],
        "path": [list(p) for p in (all_paths[0] if all_paths else [])]
    }

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/state", methods=["GET"])
def api_state():
    return jsonify(build_response(STATE["rows"], STATE["cols"], STATE["start"], STATE["goal"], STATE["obstacles"]))

@app.route("/api/solve", methods=["POST"])
def api_solve():
    data = request.get_json(force=True)
    rows, cols = clamp(int(data.get("rows", 15)), 2, 60), clamp(int(data.get("cols", 15)), 2, 60)
    start = (clamp(int(data["start"][0]), 0, rows-1), clamp(int(data["start"][1]), 0, cols-1))
    goal = (clamp(int(data["goal"][0]), 0, rows-1), clamp(int(data["goal"][1]), 0, cols-1))
    
    obs = set()
    for o in data.get("obstacles", []):
        r, c = int(o[0]), int(o[1])
        if 0 <= r < rows and 0 <= c < cols: obs.add((r, c))
    
    obs.discard(start); obs.discard(goal)
    STATE.update({"rows": rows, "cols": cols, "start": start, "goal": goal, "obstacles": obs})
    
    payload = { "rows": rows, "cols": cols, "start": list(start), "goal": list(goal), "obstacles": [list(x) for x in obs] }
    with open(STATE_FILE, "w") as f: json.dump(payload, f)
    
    return jsonify(build_response(rows, cols, start, goal, obs))

if __name__ == "__main__":
    app.run(debug=True, port=5000)