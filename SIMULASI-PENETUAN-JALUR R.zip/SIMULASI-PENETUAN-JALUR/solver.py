import time
from collections import deque, defaultdict

DIRS4 = [(-1, 0), (1, 0), (0, -1), (0, 1)]

def in_bounds(r, c, rows, cols):
    return 0 <= r < rows and 0 <= c < cols

def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

# =========================================================
# 1) SINGLE ROBOT & STATS (MODIFIKASI UNTUK 3 JALUR)
# =========================================================
def solve_with_stats(rows, cols, start, goal, obstacles):
    """
    Fungsi utama yang dipanggil oleh app.py untuk mode single-robot.
    Mengembalikan statistik dan daftar beberapa jalur (all_paths).
    """
    t0 = time.perf_counter()
    
    # Dapatkan hingga 5 jalur alternatif menggunakan teknik blocking
    paths = k_alternative_paths(rows, cols, start, goal, obstacles, k=5)
    
    # Hitung node yang dikunjungi (menggunakan BFS standar sebagai representasi)
    _, visited_count = bfs_shortest_path(rows, cols, start, goal, obstacles)
    
    t1 = time.perf_counter()
    
    return {
        "status": "success" if paths else "not_found",
        "nodes": int(visited_count),
        "time_ms": float((t1 - t0) * 1000.0),
        "path": paths[0] if paths else [],
        "all_paths": paths[:3]  # Mengambil 3 jalur pertama untuk UI
    }

def bfs_shortest_path(rows, cols, start, goal, obstacles):
    obs = set(obstacles)
    if start in obs or goal in obs:
        return [], 0

    q = deque([start])
    prev = {start: None}
    visited = 0

    while q:
        cur = q.popleft()
        visited += 1
        if cur == goal:
            break

        cr, cc = cur
        for dr, dc in DIRS4:
            nr, nc = cr + dr, cc + dc
            if in_bounds(nr, nc, rows, cols) and (nr, nc) not in obs and (nr, nc) not in prev:
                prev[(nr, nc)] = cur
                q.append((nr, nc))

    if goal not in prev:
        return [], visited

    path = []
    cur = goal
    while cur is not None:
        path.append(cur)
        cur = prev[cur]
    path.reverse()
    return path, visited

# =========================================================
# 2) K-ALTERNATIVE PATHS (TEKNIK BLOCKING)
# =========================================================
def k_alternative_paths(rows, cols, start, goal, obstacles, k=5):
    """
    Menghasilkan jalur alternatif dengan memblokir node dari jalur utama.
    """
    obs = set(obstacles)
    main_path, _ = bfs_shortest_path(rows, cols, start, goal, obs)
    if not main_path:
        return []

    results = [main_path]
    seen = {tuple(main_path)}

    # Iterasi melalui node di jalur utama (kecuali start dan goal)
    for i in range(1, len(main_path) - 1):
        if len(results) >= k:
            break
        
        # Blokir satu node dari jalur utama untuk memaksa BFS mencari jalan lain
        temp_obs = obs | {main_path[i]}
        alt_path, _ = bfs_shortest_path(rows, cols, start, goal, temp_obs)
        
        if alt_path and tuple(alt_path) not in seen:
            seen.add(tuple(alt_path))
            results.append(alt_path)

    results.sort(key=len)
    return results

# =========================================================
# 3) MULTI-ROBOT COLLISION AVOIDANCE
# =========================================================
def _edge_conflict(a_from, a_to, b_from, b_to):
    return a_from == b_to and a_to == b_from

def _build_timed_path(path, delay, round_trip=True):
    if not path: return []
    # Jika round_trip aktif, robot akan kembali ke start setelah sampai goal
    p = list(path)
    if round_trip:
        p += list(reversed(path[:-1]))
    return [p[0]] * delay + p

def _collision_free(timed_paths):
    if not timed_paths: return True
    max_t = max(len(tp) for tp in timed_paths)
    
    for t in range(max_t):
        pos_at_t = {}
        for i, tp in enumerate(timed_paths):
            if not tp: continue
            # Jika t melebihi panjang path, robot dianggap diam di posisi terakhir
            pos = tp[t] if t < len(tp) else tp[-1]
            
            # Cek Vertex Conflict (dua robot di kotak yang sama)
            if pos in pos_at_t: return False
            pos_at_t[pos] = i
            
            # Cek Edge Conflict (tukar posisi)
            if t > 0:
                prev_pos = tp[t-1] if (t-1) < len(tp) else tp[-1]
                for j, other_tp in enumerate(timed_paths):
                    if i == j or not other_tp: continue
                    other_curr = other_tp[t] if t < len(other_tp) else other_tp[-1]
                    other_prev = other_tp[t-1] if (t-1) < len(other_tp) else other_tp[-1]
                    if _edge_conflict(prev_pos, pos, other_prev, other_curr):
                        return False
    return True

def plan_multi_robot(rows, cols, robots, obstacles, k_paths=6, max_delay=12):
    """
    Logika perencanaan untuk banyak robot agar tidak tabrakan.
    """
    t0 = time.perf_counter()
    obs = set(obstacles)
    all_results = []
    
    # Skenario sederhana: setiap robot mengambil jalur terpendek dengan delay berbeda
    # Ini menjamin fungsionalitas dasar tanpa backtracking yang berat
    collision_free = False
    for delay_step in range(max_delay):
        current_timed = []
        planned = []
        for i, rb in enumerate(robots):
            path, _ = bfs_shortest_path(rows, cols, rb["start"], rb["goal"], obs)
            delay = i * delay_step
            tp = _build_timed_path(path, delay)
            current_timed.append(tp)
            planned.append({
                "id": rb["id"],
                "path": path,
                "delay": delay,
                "timed_path": tp
            })
        
        if _collision_free(current_timed):
            all_results = planned
            collision_free = True
            break
            
    t1 = time.perf_counter()
    return all_results, collision_free, float((t1 - t0) * 1000.0)