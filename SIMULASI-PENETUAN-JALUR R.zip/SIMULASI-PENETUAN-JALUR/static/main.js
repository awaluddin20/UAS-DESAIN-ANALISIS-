import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";

const canvas = document.getElementById("canvas");

/**
 * ✅ MENAMBAHKAN STYLE GLOBAL
 */
const globalStyle = document.createElement('style');
globalStyle.innerHTML = `
  * { 
    font-family: 'Courier New', Courier, monospace !important; 
  }
  #status { 
    white-space: pre-wrap; 
    line-height: 1.5; 
    font-weight: bold;
  }
`;
document.head.appendChild(globalStyle);

// panel
const rowsEl = document.getElementById("rows");
const colsEl = document.getElementById("cols");
const startREl = document.getElementById("startR");
const startCEl = document.getElementById("startC");
const goalREl  = document.getElementById("goalR");
const goalCEl  = document.getElementById("goalC");
const robotCountEl = document.getElementById("robotCount");

const obstaclesEl = document.getElementById("obstacles");
const statusEl     = document.getElementById("status");

const btnUpdate = document.getElementById("btnUpdate");
const btnPlay   = document.getElementById("btnPlay");
const btnReset  = document.getElementById("btnReset");

const btnModeCar  = document.getElementById("btnModeCar");
const btnModeGoal = document.getElementById("btnModeGoal");
const btnModeObs  = document.getElementById("btnModeObs");

// ✅ ambil dropdown path
const pathSelectEl = document.getElementById("pathSelect") || document.getElementById("path");

// ===== scene
let scene, camera, renderer, controls;
let gridGroup, obstacleGroup, pathGroup, markerGroup;

let cellMeshes = [];
let cellIndexMap = new Map();
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();

let gridData = null;
let obstacleSet = new Set(); // "r,c"

// ✅ hanya 1 robot
let robots = [];          
let robotMesh = null;     

// ✅ PATHS (utama + alternatif)
let allPaths = [];            
let selectedPathIndex = 0;    

// anim
let animTimer = null;
let playing = false;
let stepIndex = 0;

// mode
let mode = "obs"; 

// visuals
const CELL = 1.0;
const GAP = 0.02;
const FLOOR_H = 0.10;
const OB_H = 0.9;

const ROBOT_SCALE = 1.25;        
const PATH_DOT_SIZE = 0.18;      
const PATH_DOT_Y = 0.05;

// glow pulse
const glowClock = new THREE.Clock();
let ringMatRef = null;
let ringLightRef = null;

init();
loadState();

// --- FUNGSI DROP DOWN & UI EVENTS ---
function fillPathDropdown(){
  if (!pathSelectEl) return;
  const n = (Array.isArray(allPaths) && allPaths.length) ? allPaths.length : 0;
  pathSelectEl.innerHTML = "";
  if (n === 0) {
    const opt = document.createElement("option");
    opt.textContent = "Tidak ada jalur";
    pathSelectEl.appendChild(opt);
    return;
  }
  for (let i=0; i<n; i++){
    const opt = document.createElement("option");
    opt.value = String(i);
    const label = i === 0 ? " (Terpendek)" : " (Alternatif)";
    opt.textContent = `Path ${i+1}${label}`;
    pathSelectEl.appendChild(opt);
  }
  const idx = Math.min(selectedPathIndex, n-1);
  pathSelectEl.value = String(idx);
}

pathSelectEl?.addEventListener("change", () => {
  selectedPathIndex = parseInt(pathSelectEl.value || "0", 10) || 0;
  if (robots?.length && Array.isArray(allPaths) && allPaths.length){
    const p = allPaths[Math.min(selectedPathIndex, allPaths.length - 1)];
    robots[0].timed_path = Array.isArray(p) ? p : [];
  }
  stop();
  stepIndex = 0;
  buildPlannedPath(gridData);
  placeRobotAtT(0);
  updateStatus();
});

btnUpdate?.addEventListener("click", () => { stop(); solveFromPanel(); });
btnPlay?.addEventListener("click", () => {
  if (!robots?.length) return;
  if (playing) stop(); else play();
});
btnReset?.addEventListener("click", () => {
  stop();
  stepIndex = 0;
  placeRobotAtT(0);
  updateStatus();
});

function setMode(m){
  mode = m;
  btnModeCar?.classList.toggle("active", m === "car");
  btnModeGoal?.classList.toggle("active", m === "goal");
  btnModeObs?.classList.toggle("active", m === "obs");
}
btnModeCar?.addEventListener("click", ()=>setMode("car"));
btnModeGoal?.addEventListener("click", ()=>setMode("goal"));
btnModeObs?.addEventListener("click", ()=>setMode("obs"));

let pointerDown = null;
canvas.addEventListener("pointerdown", (e) => { pointerDown = { x: e.clientX, y: e.clientY }; });
canvas.addEventListener("pointerup", (e) => {
  if (!pointerDown) return;
  const dx = e.clientX - pointerDown.x;
  const dy = e.clientY - pointerDown.y;
  if (Math.hypot(dx, dy) < 6) onCanvasClick(e);
  pointerDown = null;
});

// ===== INIT =====
function init(){
  scene = new THREE.Scene();
  scene.background = null; 

  renderer = new THREE.WebGLRenderer({ canvas, antialias:true, alpha: true });
  renderer.setPixelRatio(window.devicePixelRatio || 1);

  camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 2000);
  camera.position.set(18, 22, 18);

  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.target.set(0, 0, 0);

  const hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 1.2);
  scene.add(hemi);

  const dir = new THREE.DirectionalLight(0xffffff, 1.0);
  dir.position.set(20, 40, 10);
  scene.add(dir);

  window.addEventListener("resize", onResize);
  onResize();
  animate();
}

function onResize(){
  const w = window.innerWidth;
  const h = window.innerHeight;
  renderer.setSize(w, h, false);
  camera.aspect = w/h;
  camera.updateProjectionMatrix();
}

function animate(){
  requestAnimationFrame(animate);
  controls.update();
  updateRobotGlow();
  renderer.render(scene, camera);
}

async function loadState(){
  statusEl.textContent = "Status: Memuat...";
  const res = await fetch("/api/state", { cache:"no-store" });
  gridData = await res.json();
  applyToPanel(gridData);
  buildAll(gridData);
  updateStatus();
}

function applyToPanel(g){
  rowsEl.value = g.rows;
  colsEl.value = g.cols;
  startREl.value = g.start[0];
  startCEl.value = g.start[1];
  goalREl.value  = g.goal[0];
  goalCEl.value  = g.goal[1];
  if (robotCountEl) { robotCountEl.value = 1; robotCountEl.disabled = true; }
  obstacleSet = new Set((g.obstacles || []).map(o => `${o[0]},${o[1]}`));
  if (obstaclesEl) obstaclesEl.value = [...obstacleSet].join(";");
  
  if (g.robots && g.robots.length) robots = [g.robots[0]];
  else robots = [{ id: 1, start: [g.start[0], g.start[1]], goal: [g.goal[0], g.goal[1]], timed_path: [] }];

  allPaths = Array.isArray(g.paths) ? g.paths : (Array.isArray(g.all_paths) ? g.all_paths : []);
  selectedPathIndex = Number.isInteger(g.selected_path_index) ? g.selected_path_index : 0;
  if (selectedPathIndex < 0) selectedPathIndex = 0;

  if (robots?.length && allPaths.length){
    const p = allPaths[Math.min(selectedPathIndex, allPaths.length - 1)];
    robots[0].timed_path = Array.isArray(p) ? p : (robots[0].timed_path || []);
  }
  fillPathDropdown();
}

async function solveFromPanel(){
  const rows = parseInt(rowsEl.value || "15", 10);
  const cols = parseInt(colsEl.value || "15", 10);
  if (rows * cols > 2500) { alert("Grid terlalu besar!"); return; }
  const sr = parseInt(startREl.value || "0", 10);
  const sc = parseInt(startCEl.value || "0", 10);
  const gr = parseInt(goalREl.value  || "0", 10);
  const gc = parseInt(goalCEl.value  || "0", 10);
  const obstacles = [...obstacleSet].map(s => s.split(",").map(Number));

  statusEl.textContent = "Status: Menghitung...";
  const res = await fetch("/api/solve", {
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({ rows, cols, start: [sr, sc], goal: [gr, gc], robot_count: 1, obstacles })
  });
  gridData = await res.json();
  applyToPanel(gridData);
  buildAll(gridData);
  stepIndex = 0;
  updateStatus();
}

function clearGroups(){
  for (const g of [gridGroup, obstacleGroup, pathGroup, markerGroup]){ if (g) scene.remove(g); }
  gridGroup = new THREE.Group(); obstacleGroup = new THREE.Group();
  pathGroup = new THREE.Group(); markerGroup = new THREE.Group();
  scene.add(gridGroup, obstacleGroup, pathGroup, markerGroup);
  cellMeshes = []; cellIndexMap.clear();
  robotMesh = null; ringMatRef = null; ringLightRef = null;
}

function buildAll(g){
  clearGroups();
  buildGrid(g);
  buildObstacles(g);
  buildTargetMarker(g);
  buildSingleRobot(g);
  buildPlannedPath(g);
  frameCamera(g);
}

function buildGrid(g){
  const floorGeo = new THREE.BoxGeometry(CELL - GAP, FLOOR_H, CELL - GAP);
  for (let r=0; r<g.rows; r++){
    for (let c=0; c<g.cols; c++){
      const isEven = ((r+c)%2===0);
      const col = isEven ? 0xf3f4f6 : 0xe5e7eb;
      const mat = new THREE.MeshStandardMaterial({ color: col, roughness: 0.95 });
      const cell = new THREE.Mesh(floorGeo, mat);
      const {x,z} = cellToWorld(r,c,g.rows,g.cols);
      cell.position.set(x, -FLOOR_H/2, z);
      gridGroup.add(cell);
      cellMeshes.push(cell);
      cellIndexMap.set(cell.id, {r,c});
    }
  }
  addThinGridLines(g);
}

function addThinGridLines(g){
  const rows = g.rows, cols = g.cols;
  const w = cols * CELL, h = rows * CELL;
  const points = [];
  for (let i=0; i<=cols; i++){
    const x = -w/2 + i*CELL;
    points.push(new THREE.Vector3(x, 0.002, -h/2), new THREE.Vector3(x, 0.002, h/2));
  }
  for (let i=0; i<=rows; i++){
    const z = -h/2 + i*CELL;
    points.push(new THREE.Vector3(-w/2, 0.002, z), new THREE.Vector3(w/2, 0.002, z));
  }
  const geo = new THREE.BufferGeometry().setFromPoints(points);
  gridGroup.add(new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: 0x94a3b8, transparent: true, opacity: 0.4 })));
}

/**
 * ✅ OBSTACLE PERTEGAS (DENGAN OUTLINE)
 */
function buildObstacles(g){
  obstacleGroup.clear();
  const geo = new THREE.BoxGeometry(CELL - 0.05, OB_H, CELL - 0.05);
  const mat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.7, metalness: 0.2 });
  const edgeMat = new THREE.LineBasicMaterial({ color: 0x000000 });
  const edgeGeo = new THREE.EdgesGeometry(geo);

  for (const key of obstacleSet){
    const [r,c] = key.split(",").map(Number);
    if (r<0 || r>=g.rows || c<0 || c>=g.cols) continue;
    const {x,z} = cellToWorld(r,c,g.rows,g.cols);
    
    const box = new THREE.Mesh(geo, mat);
    box.position.set(x, OB_H/2, z);
    obstacleGroup.add(box);

    const edges = new THREE.LineSegments(edgeGeo, edgeMat);
    edges.position.copy(box.position);
    obstacleGroup.add(edges);
  }
}

/**
 * ✅ TARGET FINISH (KOTAK-KOTAK / CHECKERBOARD)
 */
function buildTargetMarker(g){
  const group = new THREE.Group();
  
  // Tekstur Papan Catur Sederhana
  const canvasCheck = document.createElement('canvas');
  canvasCheck.width = 64; canvasCheck.height = 64;
  const ctx = canvasCheck.getContext('2d');
  ctx.fillStyle = "#ffffff"; ctx.fillRect(0,0,64,64);
  ctx.fillStyle = "#000000";
  ctx.fillRect(0,0,32,32); ctx.fillRect(32,32,32,32);
  const texture = new THREE.CanvasTexture(canvasCheck);
  texture.magFilter = THREE.NearestFilter;
  texture.repeat.set(2, 2); texture.wrapS = texture.wrapT = THREE.RepeatWrapping;

  // Alas Finish Kotak-kotak
  const finishBase = new THREE.Mesh(
    new THREE.BoxGeometry(CELL - 0.05, 0.02, CELL - 0.05),
    new THREE.MeshStandardMaterial({ map: texture })
  );
  finishBase.position.y = 0.01;
  group.add(finishBase);

  // Tiang perak
  const pole = new THREE.Mesh(
    new THREE.CylinderGeometry(0.02, 0.02, 0.8, 12),
    new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8, roughness: 0.2 })
  );
  pole.position.y = 0.4;
  group.add(pole);

  // Bendera merah
  const flag = new THREE.Mesh(
    new THREE.BoxGeometry(0.35, 0.22, 0.02),
    new THREE.MeshStandardMaterial({ color: 0xef4444 })
  );
  flag.position.set(0.18, 0.68, 0);
  group.add(flag);

  const {x,z} = cellToWorld(g.goal[0], g.goal[1], g.rows, g.cols);
  group.position.set(x, 0, z);
  markerGroup.add(group);
}

function buildSingleRobot(g){
  const sr = g.start[0], sc = g.start[1];
  if (!robots.length) robots = [{ id: 1, start: [sr, sc], goal: [g.goal[0], g.goal[1]], timed_path: [] }];
  if (allPaths && allPaths.length){
    const p = allPaths[Math.min(selectedPathIndex, allPaths.length - 1)];
    robots[0].timed_path = Array.isArray(p) ? p : [];
  }
  robotMesh = buildRobotMeshLikeRobot();
  robotMesh.scale.setScalar(ROBOT_SCALE);
  markerGroup.add(robotMesh);
  placeRobotAtT(0);
}

/**
 * ✅ ROBOT MECHA DETAIL (VISOR & BODY HIJAU)
 */
function buildRobotMeshLikeRobot(){
  const group = new THREE.Group();
  
  const matBody = new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.4 });
  const matDark = new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.5 });
  const matGlow = new THREE.MeshStandardMaterial({ color: 0x4ade80, emissive: 0x4ade80, emissiveIntensity: 2 });

  // Chassis Bawah
  const chassis = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.15, 0.5), matDark);
  chassis.position.y = 0.12;
  group.add(chassis);

  // Body Atas
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.25, 0.4), matBody);
  body.position.y = 0.3;
  group.add(body);

  // Visor / Mata Hijau Bersinar
  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.08, 0.05), matGlow);
  visor.position.set(0, 0.33, 0.2);
  group.add(visor);

  // Roda (4 buah)
  const wheelGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.1, 16);
  const wPos = [[-0.3, 0.12, 0.18], [0.3, 0.12, 0.18], [-0.3, 0.12, -0.18], [0.3, 0.12, -0.18]];
  wPos.forEach(p => {
    const w = new THREE.Mesh(wheelGeo, matDark);
    w.rotation.z = Math.PI / 2;
    w.position.set(p[0], p[1], p[2]);
    group.add(w);
  });

  // Antena
  const ant = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.25), matDark);
  ant.position.set(0.12, 0.5, -0.1);
  group.add(ant);

  // Ring Cahaya Bawah
  const ringMat = new THREE.MeshStandardMaterial({ color: 0x22c55e, emissive: 0x22c55e, emissiveIntensity: 1 });
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.35, 0.03, 8, 32), ringMat);
  ring.rotation.x = Math.PI/2; ring.position.y = 0.05;
  
  const glow = new THREE.PointLight(0x22c55e, 1.5, 2);
  glow.position.y = 0.3;

  group.add(ring, glow);
  ringMatRef = ringMat; ringLightRef = glow;
  return group;
}

function updateRobotGlow(){
  if (!ringMatRef || !ringLightRef) return;
  const pulse = 0.6 + 0.4 * Math.sin(glowClock.getElapsedTime() * 4);
  ringMatRef.emissiveIntensity = 1 + pulse;
  ringLightRef.intensity = 1 + pulse;
}

function placeRobotAtT(t){
  if (!gridData || !robotMesh || !robots.length) return;
  const tp = robots[0].timed_path || [];
  let [r, c] = tp.length && t < tp.length ? tp[t] : (robots[0].start || [0,0]);
  
  // Rotasi robot menghadap arah jalan
  if (tp.length > 1 && t < tp.length - 1) {
      const next = tp[t+1];
      const curr = tp[t];
      const dr = next[0] - curr[0];
      const dc = next[1] - curr[1];
      if (dr === 1) robotMesh.rotation.y = 0;
      else if (dr === -1) robotMesh.rotation.y = Math.PI;
      else if (dc === 1) robotMesh.rotation.y = -Math.PI/2;
      else if (dc === -1) robotMesh.rotation.y = Math.PI/2;
  }

  const {x,z} = cellToWorld(r,c,gridData.rows,gridData.cols);
  robotMesh.position.set(x, 0.03, z);
}

function buildPlannedPath(g){
  pathGroup.clear();
  if (!g || !allPaths || allPaths.length === 0) return;
  const pathColors = [0x22c55e, 0xfacc15, 0xef4444];
  allPaths.forEach((path, pIdx) => {
    if (pIdx > 2) return;
    const isSelected = (pIdx === selectedPathIndex);
    const mat = new THREE.MeshStandardMaterial({ color: pathColors[pIdx], transparent: true, opacity: isSelected ? 1 : 0.4 });
    path.forEach(([r, c]) => {
      const {x, z} = cellToWorld(r, c, g.rows, g.cols);
      const dot = new THREE.Mesh(new THREE.BoxGeometry(PATH_DOT_SIZE, 0.06, PATH_DOT_SIZE), mat);
      dot.position.set(x, PATH_DOT_Y + (pIdx * 0.01), z);
      pathGroup.add(dot);
    });
  });
}

function frameCamera(g){
  const maxDim = Math.max(g.rows, g.cols);
  camera.position.set(maxDim*0.8, maxDim*1, maxDim*0.8);
  controls.target.set(0, 0, 0);
  controls.update();
}

function play(){ playing = true; if (btnPlay) btnPlay.textContent = "Stop"; animTimer = setInterval(() => stepForward(), 170); }
function stop(){ playing = false; if (btnPlay) btnPlay.textContent = "Play"; clearInterval(animTimer); }
function stepForward(){
  const tp = robots[0]?.timed_path || [];
  if (stepIndex >= tp.length - 1){ stop(); return; }
  stepIndex++; placeRobotAtT(stepIndex); updateStatus();
}

function onCanvasClick(ev){
  if (!gridData) return;
  const rect = canvas.getBoundingClientRect();
  mouse.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -(((ev.clientY - rect.top) / rect.height) * 2 - 1);
  raycaster.setFromCamera(mouse, camera);
  const hits = raycaster.intersectObjects(cellMeshes);
  if (!hits.length) return;
  const {r,c} = cellIndexMap.get(hits[0].object.id);
  const key = `${r},${c}`;
  if (mode === "car") { startREl.value = r; startCEl.value = c; solveFromPanel(); }
  else if (mode === "goal") { goalREl.value = r; goalCEl.value = c; solveFromPanel(); }
  else if (mode === "obs") { 
    if (obstacleSet.has(key)) obstacleSet.delete(key); else obstacleSet.add(key);
    buildObstacles(gridData); solveFromPanel();
  }
}

function updateStatus(){
  const tp = robots[0]?.timed_path || [];
  statusEl.textContent = `[ LAPORAN SISTEM ROBOT ]\n---------------------------------------\nSTATUS : ${tp.length ? "DIJALANKAN" : "MENCARI..."}\nGRID   : ${gridData?.rows}x${gridData?.cols}\nSTEP   : ${stepIndex}/${Math.max(0, tp.length-1)}\n---------------------------------------`;
}

function cellToWorld(r,c,rows,cols){
  return { x: (c*CELL) - (cols*CELL)/2 + CELL/2, z: (r*CELL) - (rows*CELL)/2 + CELL/2 };
}